import AddStoryPresenter from './add-story-presenter';
import StoryModel from '../../data/story-model';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

// Configure Leaflet's default icon
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x, // Add this line for retina displays
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

export default class AddStoryView {
  #presenter;

  constructor() {
    this._presenter = null;
  }

  async render() {
    return `
      <section class="container">
        <h1 class="page-title">Add New Story</h1>
        <form id="add-story-form" class="story-form">
          <div class="form-group">
            <label for="description" class="form-label">Description:</label>
            <textarea id="description" name="description" class="form-input" required></textarea>
          </div>

          <div class="form-group">
            <label class="form-label">Choose Photo:</label>
            <div class="photo-options">
              <input type="radio" id="upload-option" name="photo-option" value="upload" checked />
              <label for="upload-option">Upload from Device</label>
              <input type="radio" id="camera-option" name="photo-option" value="camera" />
              <label for="camera-option">Take Photo with Webcam</label>
            </div>
          </div>

          <div id="upload-container" class="photo-container">
            <label for="photo" class="form-label">Upload Photo:</label>
            <input type="file" id="photo" name="photo" accept="image/*" class="form-input" />
          </div>

          <div id="camera-container" class="photo-container" style="display: none;">
            <video id="camera-preview" autoplay class="camera-preview"></video>
            <button type="button" id="capture-button" class="capture-button">Capture Photo</button>
            <canvas id="camera-canvas" style="display: none;"></canvas>
            <img id="photo-preview" class="captured-photo-preview" alt="Captured photo preview" style="display: none;" /> 
          </div>

          <div class="form-group">
            <button type="submit" class="submit-button">Submit</button>
          </div>
        </form>

        <div id="map" class="map-container"></div>
        <h2 class="section-title">Other People's Stories</h2>
        <div id="stories-container" class="stories-container"></div>
      </section>
    `;
  }

  async afterRender() {
    const model = new StoryModel();
    this.#presenter = new AddStoryPresenter(model, this);
    this.#presenter.init();

    // Handler to stop camera
    const stopCameraHandler = () => {
      if (this.#presenter && typeof this.#presenter.cleanup === 'function') {
        this.#presenter.cleanup();
      }
    };

    // Remove previous listeners to avoid duplicates
    window.removeEventListener('beforeunload', stopCameraHandler);
    window.removeEventListener('hashchange', stopCameraHandler);

    // Add listeners to stop camera on navigation or refresh
    window.addEventListener('beforeunload', stopCameraHandler);
    window.addEventListener('hashchange', stopCameraHandler);
  }

  getFormElements() {
    const form = document.querySelector('#add-story-form');
    const description = document.querySelector('#description');
    const photoInput = document.querySelector('#photo');
    const uploadOption = document.querySelector('#upload-option');
    const cameraOption = document.querySelector('#camera-option');
    const captureButton = document.querySelector('#capture-button');
    const video = document.querySelector('#camera-preview');
    const canvas = document.querySelector('#camera-canvas');
    return { form, description, photoInput, uploadOption, cameraOption, captureButton, video, canvas };
  }

  getMapElement() {
    return document.querySelector('#map');
  }

  clearMarkers(map) {
    map.eachLayer((layer) => {
      if (layer instanceof L.Marker) {
        map.removeLayer(layer);
      }
    });
  }

  addMarker(map, lat, lon) {
    L.marker([lat, lon])
      .addTo(map)
      .bindPopup('Selected Location')
      .openPopup();
  }

  showMessage(message) {
    alert(message);
  }

  resetForm() {
    const { form, photoInput, uploadOption, cameraOption } = this.getFormElements();
    form.reset();
    photoInput.value = '';
    uploadOption.checked = true;
    cameraOption.checked = false;
  }

  displayCapturedPhoto(photoDataUrl) {
    const photoPreview = document.querySelector('#photo-preview');
    if (!photoPreview) {
      console.error('Photo preview element not found in the DOM.');
      return;
    }
    photoPreview.src = photoDataUrl;
    photoPreview.style.display = 'block';
  }

  showCameraContainer() {
    const cameraContainer = document.querySelector('#camera-container');
    const uploadContainer = document.querySelector('#upload-container');
    cameraContainer.style.display = 'block';
    uploadContainer.style.display = 'none';
  }

  showUploadContainer() {
    const cameraContainer = document.querySelector('#camera-container');
    const uploadContainer = document.querySelector('#upload-container');
    cameraContainer.style.display = 'none';
    uploadContainer.style.display = 'block';
  }

  resetForm() {
    const { form, uploadOption, cameraOption, video } = this.getFormElements();

    // Reset the form fields
    form.reset();

    // Set the default radio option to "Upload from Device"
    uploadOption.checked = true;
    cameraOption.checked = false;

    // Show the upload container and hide the camera container
    this.showUploadContainer();

    // Stop the webcam if it is active
    if (video.srcObject) {
      video.srcObject.getTracks().forEach((track) => track.stop());
      video.srcObject = null;
    }
  }

  updateStoriesContainer(stories) {
    const container = document.querySelector('#stories-container');
    container.innerHTML = '';

    stories.forEach((story) => {
      const storyElement = document.createElement('div');
      storyElement.className = 'story-card';
      storyElement.innerHTML = `
        <a href="#/story/${story.id}">
          <img src="${story.photoUrl}" alt="Story by ${story.name}" class="story-image" />
          <div class="story-content">
            <h3>${story.name}</h3>
            <p>${story.description}</p>
          </div>
        </a>
      `;
      container.appendChild(storyElement);
    });
  }

  showMessage(message) {
    alert(message);
  }

  bindCameraOptionChange(startCamera, stopCamera) {
    const { uploadOption, cameraOption } = this.getFormElements();

    cameraOption.addEventListener('change', () => {
      this.showCameraContainer();
      startCamera();
    });

    uploadOption.addEventListener('change', () => {
      this.showUploadContainer();
      stopCamera(); // This will stop the camera when switching to upload
    });
  }

  bindCapturePhoto(handler) {
    const { captureButton, video, canvas } = this.getFormElements();

    captureButton.addEventListener('click', () => {
      const context = canvas.getContext('2d');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0, canvas.width, canvas.height);

      handler(canvas); // Pass the canvas to the presenter
    });
  }

  bindFormSubmit(handler) {
    const form = document.querySelector('#add-story-form');
    form.addEventListener('submit', handler);
  }

  async startCamera() {
    const { video } = this.getFormElements();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      video.srcObject = stream;
      video.style.display = 'block';
      return stream; // Return the stream to the presenter if needed
    } catch (error) {
      this.showMessage('Unable to access the webcam. Please check your permissions.');
      throw error;
    }
  }

  stopCamera() {
    const { video } = this.getFormElements();
    if (video && video.srcObject) {
      video.srcObject.getTracks().forEach((track) => track.stop()); // Stop all tracks
      video.srcObject = null; // Clear the video source
    }
    if (video) {
      video.style.display = 'none'; // Hide the video element
    }
  }
}